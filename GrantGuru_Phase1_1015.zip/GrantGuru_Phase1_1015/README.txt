GrantGuru Team - COS 457 - Fall 2025

Abdullahi Abdullahi: abdullahi.abdullahi@maine.edu
Mathieu Poulin: mathieu.poulin@maine.edu
James Tedder: james.tedder@maine.edu
Colby Wirth: colby.wirth@maine.edu, (Team Leader) 
